// 初始化地圖
const map = L.map("map").setView([25.0330, 121.5654], 13);

L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
  attribution: "© OpenStreetMap"
}).addTo(map);

