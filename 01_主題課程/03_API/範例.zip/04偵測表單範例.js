//透過表單新增地點
document.getElementById("foodForm").addEventListener("submit", e => {
  e.preventDefault();

  const place = {
    name: nameInput.value,
    lat: latInput.value,
    lng: lngInput.value,
    comment: commentInput.value
  };

  addPlace(place).then(() => {
    document.getElementById("foodForm").reset();
  });
  
});