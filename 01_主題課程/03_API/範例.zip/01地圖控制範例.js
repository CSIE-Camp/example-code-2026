// 用來管理所有 marker（方便刪除）
const markers = {};

// 將 marker 加到地圖
function addMarkerToMap(place) {
  const marker = L.marker([
    Number(place.lat),
    Number(place.lng)
  ]).addTo(map);

  //按下 marker 後顯示的東西，可自己加東西
  marker.bindPopup(`

    

    <b>${place.name}</b><br>
    ${place.comment}<br><br>
    <button onclick="deletePlace('${place.id}')">
      Delete
    </button>



  `);

  markers[place.id] = marker;
}