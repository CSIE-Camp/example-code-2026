// 刪除地點
function deletePlace(id) {
  const params = new URLSearchParams();
  params.append("action", "delete");
  params.append("id", id);

  fetch(sheet_url, {
    method: "POST",
    body: params
  })
    .then(res => res.json())
    .then(() => {
      map.removeLayer(markers[id]);
      delete markers[id];
    });
}
