// 取得sheet api
const sheet_url = "";

// 從試算表讀取資料
fetch(sheet_url)
  .then(res => res.json())
  .then(data => {
    data.forEach(place => {
      addMarkerToMap(place);
    });
  });