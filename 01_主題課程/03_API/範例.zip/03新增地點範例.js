// 新增地點
function addPlace(place){
  const params = new URLSearchParams();
  params.append("action", "add");
  params.append("name", place.name);
  params.append("lat", place.lat);
  params.append("lng", place.lng);
  params.append("comment", place.comment);

  return fetch(sheet_url, {
    method: "POST",
    body: params
  })
    .then(res => res.json())
    .then(result => {
      addMarkerToMap({
        id: result.id,
        name: nameInput.value,
        lat: latInput.value,
        lng: lngInput.value,
        comment: commentInput.value
      });
    });
}