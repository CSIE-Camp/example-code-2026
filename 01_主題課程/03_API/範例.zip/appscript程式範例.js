//你的 google 試算表 id
const sheet_id = ""

//讀取資料(GET)
function doGet() {
  const sheet = SpreadsheetApp
    .openById(sheet_id)
    .getSheetByName("Sheet1");

  const rows = sheet.getDataRange().getValues();
  const data = [];

  for (let i = 1; i < rows.length; i++) {
    if (rows[i][5] === true) continue; // deleted === true 就跳過

    data.push({
      id: rows[i][0],
      name: rows[i][1],
      lat: rows[i][2],
      lng: rows[i][3],
      comment: rows[i][4]
    });
  }

  return ContentService
    .createTextOutput(JSON.stringify(data))
    .setMimeType(ContentService.MimeType.JSON);
}

//新增與刪除資料(POST)
function doPost(e) {

  const sheet = SpreadsheetApp
    .openById(sheet_id)
    .getSheetByName("Sheet1");

  const action = e.parameter.action;

  // ===== 新增資料 =====
  if (action === "add") {
    const id = Date.now().toString();

    sheet.appendRow([
      id,
      e.parameter.name,
      e.parameter.lat,
      e.parameter.lng,
      e.parameter.comment,
      false
    ]);

    return ContentService
      .createTextOutput(
        JSON.stringify({ success: true, id })
      )
      .setMimeType(ContentService.MimeType.JSON);
  }

  // ===== 刪除資料 =====
  if (action === "delete") {
    const deleteId = e.parameter.id;
    const rows = sheet.getDataRange().getValues();

    for (let i = 1; i < rows.length; i++) {
     if (String(rows[i][0]) === String(deleteId)) {
        sheet.getRange(i + 1, 6).setValue(true); // 第 6 欄 deleted
        break;
      }
    }

   return ContentService
      .createTextOutput(JSON.stringify({ success: true }))
      .setMimeType(ContentService.MimeType.JSON);
  }

}

