#Todo:引入模組

#Todo:存放拉霸機圖案
money = 100 

print("=== 歡迎來到正常的拉霸機遊戲 ===")

while(): #Todo:設立重複遊玩條件
    print("目前餘額:??元") #Todo:用格式化字串嵌入變數
    print("請輸入指令(任意按鍵:開始轉動拉霸機；'x':結束遊戲)")
    action =  #Todo:使用者輸入

    if(): #Todo:設立結束條件
        #Todo:結束時跳開遊戲

    money = #Todo:透過自我指派更新餘額

    r1 = #Todo:引用模組內的函式
    r2 = #Todo:引用模組內的函式
    r3 = #Todo:引用模組內的函式
    print(f"結果: [ {r1} | {r2} | {r3} ]")

    if (): #Todo:設立中獎條件
        print("「超級大獎！恭喜贏得 67 元」")
        money += 67
    else:
        print("「拉完了，並未中獎。但，賭徒哪有天天輸，何不再來一把?」")
    print() 

print("「這遊戲也就這樣了，最後餘額:??元」") #Todo:用格式化字串嵌入變數