# exercise 1
# 練習重點 : Ch1 輸出

#Todo:寫出你的第一行程式!
