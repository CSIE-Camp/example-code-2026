# exercise 2
# 練習重點 : Ch1 輸入輸出

#Todo