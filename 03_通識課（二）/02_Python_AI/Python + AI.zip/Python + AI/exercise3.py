# exercise 3
# 練習重點 : Ch3 選擇控制

# 課程編號:(1)AI大小事 (2)網路安全 (3)Python + AI (其他)查無課程

print("請輸入課程編號:")
classes = int(input())

print("Minecraft")
print("硬體裝修")
print("Python + AI")
print("查無課程")
