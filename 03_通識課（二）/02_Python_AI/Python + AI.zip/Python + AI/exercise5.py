# exercise 5
# 練習重點 : Ch6 函式

def buy(): #Todo:設定引數 
    if(): #Todo:設定條件
        print("購買成功")
        # Todo:設定回傳值
    else:
        print("餘額不足，購買失敗")
        # Todo:設定回傳值

budget = 10
print(f"當前餘額:{budget}元")
budget = buy() #Todo:自行設定引數
print(f"購買後餘額:{budget}元") 