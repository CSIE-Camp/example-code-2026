# exercise 4
# 練習重點 : Ch4 迴圈、Ch5 清單

course_list = ["JavaScript","CSS","HTML","API"]
print("以下為資工營所有主題課程:")
#Todo:將所有課程依序印出
print(f"第{}堂課為{}") #Todo:格式化字串內填入適當變數